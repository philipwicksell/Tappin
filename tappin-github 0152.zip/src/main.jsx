
import React from "react";
import ReactDOM from "react-dom/client";
import TappinApp from "./App";

ReactDOM.createRoot(document.getElementById("root")).render(
  <React.StrictMode>
    <TappinApp />
  </React.StrictMode>
);
